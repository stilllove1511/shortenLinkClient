Có tính năng đăng nhập thường và đăng nhập qua Google.\
Có tính năng quản lý (thêm sửa xóa) các link rút gọn đuôi tùy chọn.\
Phía server chia làm 2 phần: 1 phần để đăng nhập và quản lý link, 1 phần để điều hướng.
